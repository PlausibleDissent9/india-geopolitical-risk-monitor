IGRM OFFLINE AUDIT BUNDLE

Canonical release: rel:oges.fixture.2026-08-08
Release record SHA-256: e6cc1e337d78c355e64eb47614cbe9824f537b7c513be9a01369cbfd53f4e2c4

This deterministic bundle contains the exact signed release, registered schemas,
method bytes, rights decisions, object records and four compiled output artifacts.
It deliberately excludes source content not licensed for redistribution.

Do not execute code from an unauthenticated archive. First authenticate this ZIP
against a digest obtained outside the ZIP, extract it without following symlinks,
and use a separately trusted OGES/IGRM verifier whose digest matches the public
profile. Conformance establishes structural and cryptographic integrity, not the
truth of source statements, causal attribution, forecast skill or legal advice.
