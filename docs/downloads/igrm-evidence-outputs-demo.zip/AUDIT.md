IGRM OFFLINE AUDIT BUNDLE

Canonical release: rel:oges.fixture.2026-08-08
Release record SHA-256: 8fd9d220e10228552ad8a1f4b492d129278243d48882c9b37ec1c7cb758d95e8

This deterministic bundle contains the exact signed release, registered schemas,
method bytes, rights decisions, object records and four compiled output artifacts.
It deliberately excludes source content not licensed for redistribution.

Do not execute code from an unauthenticated archive. First authenticate this ZIP
against a digest obtained outside the ZIP, extract it without following symlinks,
and use a separately trusted OGES/IGRM verifier whose digest matches the public
profile. Conformance establishes structural and cryptographic integrity, not the
truth of source statements, causal attribution, forecast skill or legal advice.
